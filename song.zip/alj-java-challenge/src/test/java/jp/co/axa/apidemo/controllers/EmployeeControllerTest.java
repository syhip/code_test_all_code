package jp.co.axa.apidemo.controllers;

import jp.co.axa.apidemo.ApiDemoApplication;
import org.aspectj.lang.annotation.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ApiDemoApplication.class)
@AutoConfigureMockMvc
@ContextConfiguration
@WebAppConfiguration
public class EmployeeControllerTest {

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private FilterChainProxy springSecurityFilterChain;



    // TODO springSecurity   Because security authentication requires login

 /*   @Test
    public void getEmployees() throws Exception {
        mockMvc.perform(get("/api/v1/employees"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void getEmployee() throws Exception {
        mockMvc.perform(get("/api/v1/employees")
                .param("employeeId", String.valueOf(1)))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void saveEmployee() throws Exception {
        mockMvc.perform(post("/api/v1/employees"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void deleteEmployee() throws Exception {
        mockMvc.perform(delete("/api/v1/employees")
                .param("employeeId", String.valueOf(1)))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    public void updateEmployee() throws Exception {
        mockMvc.perform(put("/api/v1/employees")
                .param("employeeId", String.valueOf(1)))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }*/
}